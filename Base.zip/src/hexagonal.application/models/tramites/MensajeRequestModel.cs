﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hexagonal.application.models.tramites
{
    public class MensajeRequestModel
    {
        public string? codigo { get; set; }
        public string? codigoIdioma { get; set; }
    }
}
