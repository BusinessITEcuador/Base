﻿namespace hexagonal.application.models.usuario
{
    public class CuentaResponseModel
    {
        public Guid Id { get; set; }
        public string Correo { get; set; }
    }
}