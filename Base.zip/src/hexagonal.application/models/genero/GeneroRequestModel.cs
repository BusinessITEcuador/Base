﻿namespace hexagonal.application.models.genero
{
    public class GeneroRequestModel
    {
        public string Nombre { get; set; }
    }
}