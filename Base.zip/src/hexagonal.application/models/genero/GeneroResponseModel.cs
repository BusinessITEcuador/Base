﻿namespace hexagonal.application.models.genero
{
    public class GeneroResponseModel
    {
        public Guid Id { get; set; }
        public string Nombre { get; set; }
    }
}